alert("This loaded JavaScript file comes from a plugin.");
