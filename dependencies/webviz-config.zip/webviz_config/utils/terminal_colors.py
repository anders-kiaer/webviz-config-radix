RED = "\x1b[37;41m"
GREEN = "\x1b[37;42m"
YELLOW = "\x1b[37;43m"
BLUE = "\x1b[37;44m"
PURPLE = "\x1b[37;45m"

BOLD = "\x1b[1m"
END = "\x1b[0m"
