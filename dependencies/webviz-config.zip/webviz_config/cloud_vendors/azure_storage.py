import io
import os
import typing

from azure.storage.blob import ContainerClient

from ..webviz_store import WebvizStorage


class AzureStorage(WebvizStorage):
    def __init__(self) -> None:
        super().__init__()
        self._container_client = ContainerClient.from_connection_string(
            conn_str=os.environ["AZURE_STORAGE_CONNECTION_STRING"],
            container_name=os.environ["AZURE_STORAGE_CONTAINER_NAME"],
        )

    def _get_file_object(self, path: str, binary_mode: bool = True) -> typing.IO:  # type: ignore[override]

        bytes_io = io.BytesIO()
        self._container_client.download_blob(path).readinto(bytes_io)
        bytes_io.seek(0)

        if binary_mode:
            return bytes_io

        string_io = io.StringIO(bytes_io.getvalue().decode())
        bytes_io.close()
        return string_io
