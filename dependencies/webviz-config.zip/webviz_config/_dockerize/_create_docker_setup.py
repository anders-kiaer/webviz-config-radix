import os
import sys
import warnings

import jinja2
import requests

from ._get_archives import create_git_archive


PYPI_URL_ROOT = "https://pypi.org/"


def create_docker_setup(build_directory, plugin_metadata):

    template_environment = jinja2.Environment(  # nosec
        loader=jinja2.PackageLoader("webviz_config", "templates"),
        undefined=jinja2.StrictUndefined,
        autoescape=False,
    )
    template = template_environment.get_template("Dockerfile.jinja2")

    (build_directory / "Dockerfile").write_text(
        template.render(
            {
                "python_version_major": sys.version_info.major,
                "python_version_minor": sys.version_info.minor,
                "webviz_config_version": "1.2.3",
            }
        )
    )

    distributions = {
        metadata["dist_name"]: {
            "version": metadata["dist_version"],
            "download_url": metadata["download_url"],
            "source_url": metadata["source_url"],
        }
        for metadata in plugin_metadata.values()
    }

    # TODO: Add webviz-config (could happen that none webviz-config plugins are included)

    get_python_requirements(distributions, build_directory)


def get_python_requirements(distributions, build_directory):

    requirements = []

    (build_directory / "dependencies").mkdir()

    for dist_name, dist in distributions.items():
        if dist["download_url"] is None and dist["source_url"] is None:
            warnings.warn(
                f"Plugin distribution {dist_name} has no download/source URL. Will not automatically become part of built Docker image."
            )
            continue

        if dist["download_url"].startswith(PYPI_URL_ROOT):
            pypi_data = requests.get(f"{PYPI_URL_ROOT}/pypi/{dist_name}/json").json()
            pypi_releases = pypi_data["releases"].keys()
            if dist["version"] in pypi_data["releases"]:
                requirements.append(f"{dist_named}=={dist['version']}")
                continue

            if dist["source_url"] is None:
                raise RuntimeError(
                    f"Could not find version {dist['version']} of {dist_name} on PyPI. "
                    "Falling back to git source code is not possible since "
                    "project_urls['Source'] is not defined in setup.py."
                )

        archive_path = build_directory / "dependencies" / f"{dist_name}.zip"

        create_git_archive(
            dist["version"],
            source_url=os.environ.get(
                "SOURCE_URL_" + dist_name.upper().replace("-", "_"), dist["source_url"]
            ),
            archive_path=archive_path
        )
        requirements.append(archive_path.name)

    (build_directory/ "dependencies" / "requirements.txt").write_text("\n".join(requirements))

