import shutil
import zipfile
import pathlib
import warnings
import tempfile
import subprocess  # nosec

import requests


def create_git_archive(version, source_url, archive_path):
    """All webviz-config plugin projects are encouraged to be open source
    and on PyPI. Those that are not are encouraged to be on a git solution,
    and use quite standard setuptools_scm to give a runtime available version
    to the Python package.

    setuptool_scm enables us to get information regarding which hash/tag of the private
    git repository to download + install in the Docker image, as installation from a
    clean repository state should give one of the following versions:

    no distance to tag:
        {tag}
    distance:
        {next_version}.dev{distance}+g{revision hash}
    """

    source_url = source_url.rstrip("/")
    git_pointer = version.split("+g")[1] if "+" in version else version

    if source_url.startswith("http") and requests.get(source_url).status_code != 200:
        warnings.warn(f"Could not find {source_url}, changing to SSH URL")
        for string in ["https://github.com/", "https://www.github.com/"]:
            source_url = source_url.replace(string, "git@github.com:")

    repo_name = source_url.split("/")[-1]

    with tempfile.TemporaryDirectory() as temp_dir:

        path = pathlib.Path(temp_dir)

        # We can't run git archive directly since GitHub does
        # not support it being called remotely for some reason...

        print("Cloning repository " + source_url)

        subprocess.run(  # nosec
            ["git", "clone", source_url],
            cwd=path,
            check=True,
        )

        subprocess.run(  # nosec
            ["git", "archive", "--output", str(path / "raw.zip"), git_pointer],
            cwd=path / repo_name,
            check=True,
        )

        with zipfile.ZipFile(path / "raw.zip") as input_zip:
            with zipfile.ZipFile(path / "modified.zip", "w") as output_zip:
                for item in input_zip.infolist():
                    buffer = input_zip.read(item.filename)
                    if item.filename == "setup.py":
                        buffer = (
                            b"import os\n"
                            + f"os.environ['SETUPTOOLS_SCM_PRETEND_VERSION'] = '{version}'\n".encode()
                            + buffer
                        )
                    output_zip.writestr(item, buffer)

        shutil.copyfile(path / "modified.zip", archive_path)


if __name__ == "__main__":
    get_git_archive("webviz_config")
