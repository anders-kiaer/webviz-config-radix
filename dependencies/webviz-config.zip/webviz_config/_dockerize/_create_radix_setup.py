import jinja2


def create_radix_setup(build_directory):

    template_environment = jinja2.Environment(  # nosec
        loader=jinja2.PackageLoader("webviz_config", "templates"),
        undefined=jinja2.StrictUndefined,
        autoescape=False,
    )
    template = template_environment.get_template("radixconfig.yaml.jinja2")

    (build_directory / "radixconfig.yaml").write_text(
        template.render(
            {
            }
        )
    )
